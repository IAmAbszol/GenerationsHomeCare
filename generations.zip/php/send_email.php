<?php
  // sends mail to business
?>